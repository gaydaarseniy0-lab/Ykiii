package com.oxide.overlay;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 11, 8);
    private final int PANEL = Color.rgb(17, 22, 17);
    private final int GREEN = Color.rgb(166, 255, 0);
    private final int MUTED = Color.rgb(142, 153, 137);
    private LinearLayout content;
    private String currentTab = "VISUALS";
    private TextView visualsTab, aimTab, settingsTab;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(0);
        build();
        showTab("VISUALS");
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(12));
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView logo = text("OX", 26, GREEN, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(PANEL, GREEN, 12));
        header.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("OXIDE", 22, Color.WHITE, true));
        titles.addView(text("SURVIVAL ISLAND  •  ANDROID MENU", 10, MUTED, true));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView version = text("v0.1", 11, GREEN, true);
        version.setGravity(Gravity.CENTER);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(shape(PANEL, 0, 20));
        header.addView(version);
        root.addView(header);

        TextView notice = text("UI PROTOTYPE  ·  DEMO CONTROLS ONLY", 10, MUTED, true);
        notice.setPadding(dp(2), dp(14), 0, dp(12));
        root.addView(notice);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(shape(PANEL, 0, 12));
        visualsTab = tab("VISUALS");
        aimTab = tab("AIM");
        settingsTab = tab("SETTINGS");
        tabs.addView(visualsTab, new LinearLayout.LayoutParams(0, dp(42), 1));
        tabs.addView(aimTab, new LinearLayout.LayoutParams(0, dp(42), 1));
        tabs.addView(settingsTab, new LinearLayout.LayoutParams(0, dp(42), 1));
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(14), 0, dp(8));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("OXIDE  /  LOCAL INTERFACE", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, dp(4));
        root.addView(footer);

        visualsTab.setOnClickListener(v -> showTab("VISUALS"));
        aimTab.setOnClickListener(v -> showTab("AIM"));
        settingsTab.setOnClickListener(v -> showTab("SETTINGS"));
    }

    private TextView tab(String label) {
        TextView t = text(label, 11, MUTED, true);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void showTab(String tab) {
        currentTab = tab;
        styleTab(visualsTab, tab.equals("VISUALS"));
        styleTab(aimTab, tab.equals("AIM"));
        styleTab(settingsTab, tab.equals("SETTINGS"));
        content.removeAllViews();

        if (tab.equals("VISUALS")) {
            section("VISUALS", "Demo toggles for a future practice scene");
            addToggle("Player boxes (demo)", "Draw sample boxes in a local mock scene", false);
            addToggle("Distance labels (demo)", "Placeholder setting; no game data is read", false);
            addToggle("Crosshair overlay", "Show a simple in-app crosshair preview", true);
            addToggle("Highlight color", "Use the OXIDE neon accent", true);
            addAction("OPEN VISUAL PREVIEW", "Preview is a UI-only placeholder.");
        } else if (tab.equals("AIM")) {
            section("AIM LAB", "Practice tools only — no game input automation");
            addToggle("Crosshair guide", "Display a static practice guide", true);
            addToggle("Tap feedback", "Show feedback when you tap the demo button", true);
            addSlider("Crosshair size", 8, 48, 24);
            addSlider("Interface opacity", 20, 100, 90);
            addAction("TEST TAP FEEDBACK", "Tap registered in OXIDE demo.");
        } else {
            section("SETTINGS", "Customize the local menu");
            addToggle("Neon accents", "Use green highlight styling", true);
            addToggle("Compact layout", "Use tighter spacing in a future build", false);
            addSlider("UI scale", 80, 120, 100);
            addAction("RESET DEMO SETTINGS", "Demo settings reset (prototype only).");
            addAction("ABOUT OXIDE", "OXIDE Menu v0.1 • Android UI prototype");
        }
    }

    private void styleTab(TextView t, boolean active) {
        t.setTextColor(active ? GREEN : MUTED);
        t.setBackground(active ? shape(Color.rgb(28, 38, 20), GREEN, 9) : shape(Color.TRANSPARENT, 0, 9));
    }

    private void section(String title, String subtitle) {
        TextView h = text(title, 17, Color.WHITE, true);
        content.addView(h);
        TextView sub = text(subtitle, 11, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(12));
        content.addView(sub);
    }

    private void addToggle(String title, String subtitle, boolean checked) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(13), dp(10), dp(10), dp(10));
        card.setBackground(shape(PANEL, Color.rgb(35, 45, 32), 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9);
        content.addView(card, lp);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(title, 13, Color.WHITE, true));
        TextView sub = text(subtitle, 10, MUTED, false);
        sub.setPadding(0, dp(4), 0, 0);
        labels.addView(sub);
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        Switch sw = new Switch(this);
        sw.setButtonTintList(null);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener((button, value) ->
            Toast.makeText(this, title + ": " + (value ? "ON" : "OFF"), Toast.LENGTH_SHORT).show());
        card.addView(sw);
    }

    private void addSlider(String title, int min, int max, int initial) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(10), dp(13), dp(8));
        card.setBackground(shape(PANEL, Color.rgb(35, 45, 32), 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9);
        content.addView(card, lp);

        TextView label = text(title + "  ·  " + initial, 12, Color.WHITE, true);
        card.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(GREEN));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                label.setText(title + "  ·  " + (min + progress));
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        card.addView(bar);
    }

    private void addAction(String label, String message) {
        TextView button = text(label + "   →", 12, GREEN, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(12), dp(14), dp(12), dp(14));
        button.setBackground(shape(Color.rgb(20, 29, 16), GREEN, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(2);
        lp.bottomMargin = dp(9);
        content.addView(button, lp);
        button.setOnClickListener(v -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }
}
