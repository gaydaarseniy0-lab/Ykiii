# OXIDE Android Menu — UI Prototype v0.1

A native Android (Java) prototype for a neon-green OXIDE menu with Visuals, Aim Lab, and Settings tabs.

## What this is
- A local menu UI with demo toggles and sliders.
- No connection to Oxide: Survival Island.
- Does not read game memory, reveal player locations, or automate aiming/input.
- The ESP/Aim labels are UI placeholders for a permitted test scene or standalone training mode.

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Let Gradle sync.
3. Build > Build APK(s), or run on an Android device.
4. App requires Android 8.0+ (API 26).

Package: `com.oxide.overlay`
Version: `0.1`

This prototype has not been tested on a physical device. The project may need a Gradle/Android Gradle Plugin update depending on your Android Studio installation.

## Build APK with GitHub Actions (no Android Studio on your device)
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**, then **Run workflow**.
4. When the workflow finishes, download the `OXIDE-Android-Menu-debug` artifact. It contains `app-debug.apk`.

The workflow builds a debug APK; it is not a signed release build.
